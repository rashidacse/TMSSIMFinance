<?php
    define("MEMBER_APP",                                              "app.Member");
//    define("HEADER_APP",                                              "app.Header");
//    define("PHOTO_APP",                                               "app.Photo");