<?php
define("ERROR_MESSAGE_FLAG",                                  1);
define("SUCCESS_MESSAGE_FLAG",                                2);
//define("RESELLER_GROUP_ID_ADMIN",                            1);
//define("RESELLER_GROUP_ID_TYPE1",                            3);
//define("RESELLER_GROUP_ID_TYPE2",                            4);
//define("RESELLER_GROUP_ID_TYPE3",                            5);
//define("RESELLER_GROUP_ID_TYPE4",                            6);
