<?php
define("USER_ALBUM_IMAGE_PATH",                                            "resources/images/photos/");