<?php
define("SEARCH_BY_NID",                                     1);
define("SEARCH_BY_EMAIL",                                  2);
define("SEARCH_BY_MOBILE",                                3);

