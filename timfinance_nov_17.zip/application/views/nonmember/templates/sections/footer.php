<footer> 
    <div class="row">
        <div class="col-sm-12 footer_text">
            Powered By - <?php echo $site_info['title']?>
        </div>
    </div>
</footer>