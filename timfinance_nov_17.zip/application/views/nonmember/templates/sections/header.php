<header>
    <div class="">
        <div id="" class="row">
            <a id="" tabindex="-1"  style="margin-left: 100px" href="<?php echo base_url();?>">
                <img class="img-responsive" style="size: "alt="TIMFinance" src="<?php echo base_url()?>resources/images/logo.png"/>
            </a>
        </div>
        
        

    </div>
</header>