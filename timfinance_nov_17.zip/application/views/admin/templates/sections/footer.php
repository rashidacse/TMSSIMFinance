<div class="footer_bg">
    <div class="container">
        <div class="row">
            <div class="col-md-offset-2 col-md-8">
                <div class="footer_content">Office : Lake View Taslima, Ta-186, South Badda, Gulshan-1, Dhaka-1212, Bangladesh</div>
            </div>
        </div>
    </div>
</div>