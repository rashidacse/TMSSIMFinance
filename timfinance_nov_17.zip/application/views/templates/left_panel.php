<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        <ul class="sidebar-menu">

            <li class="treeview">
                <a href="#">
                    <i class="fa fa-user"></i> <span>সদস্য</span>
                    <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li ><a href="index.html"><i class="fa fa-user-o"></i> সাধারণ সদস্যের তথ্য জরীপ</a></li>
                    <li><a href="<?php echo base_url() . 'member/add_addmission_info' ?>"><i class="fa fa-user-plus"></i>সদস্য ভর্তি আবেদন ফরম</a></li>
                </ul>
            </li>

            <li class="treeview">
                <a href="#">
                    <i class="fa  fa-bank "></i> <span>প্রতিষ্ঠান সংক্রান্ত </span>
                    <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li ><a href="index.html"><i class="fa fa-institution"></i>প্রতিষ্ঠানের তথ্য </a></li>
                </ul>
            </li>

            <li class="treeview">
                <a href="#">
                    <i class="fa fa-suitcase"></i>
                    <span>ঋণ সংক্রান্ত</span>
                    <span class="pull-right-container">
              <span class="label label-primary pull-right"></span>
            </span>
                </a>
                <ul class="treeview-menu">
                    <li><a href="<?php echo base_url() . 'member/loan_application' ?>"><i class="fa fa-circle-o"></i>ঋণ আবেদন</a></li>
                    <li><a href="pages/layout/boxed.html"><i class="fa fa-circle-o"></i> ঋণ অনুমদন</a></li>
                </ul>
            </li>
            <li><a href="#"><i class="fa fa-circle-o text-aqua"></i> <span>প্রোডাক্ট</span></a></li>
            <li><a href="#"><i class="fa fa-circle-o text-red"></i> <span>পারপোজ</span></a></li>
            <li><a href="#"><i class="fa fa-circle-o text-yellow"></i> <span>বিনিয়োগকারী</span></a></li>
            <li><a href="#"><i class="fa fa-circle-o text-green"></i> <span>গ্রেচ</span></a></li>
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>