
<div class="left_menu" >
    <div class="sidebar" id="set_user_service_id">
        <ul id="navmenu">
            <li class="home"><a href="<?php echo base_url(); ?>" id="homepage" class="top">Dashboard</a></li>
        </ul>
<!--            <li>
                <a class="chld" href="javascript:void(0)">New Request</a>
                <ul id="baby">
                    <li><a href="#">Bulk Flexiload</a></li>
                    <div ng-repeat="service in serviceList">
                        <li ng-if="service.service_id == <?php echo SERVICE_TYPE_ID_BKASH_CASHIN; ?>"><a href="<?php echo base_url() . 'transaction/bkash' ?>" >bKash</a></li>
                        <li ng-if="service.service_id == <?php echo SERVICE_TYPE_ID_DBBL_CASHIN; ?>"><a href="<?php echo base_url() . 'transaction/dbbl' ?>">DBBL</a></li>
                        <li ng-if="service.service_id == <?php echo SERVICE_TYPE_ID_MCASH_CASHIN; ?>"><a href="<?php echo base_url() . 'transaction/mcash' ?>">M-Cash</a></li>
                        <li ng-if="service.service_id == <?php echo SERVICE_TYPE_ID_UCASH_CASHIN; ?>"><a href="<?php echo base_url() . 'transaction/ucash' ?>">U-Cash</a></li>
                        <li ng-if="service.service_id == <?php echo SERVICE_TYPE_ID_SEND_SMS; ?>"><a href="<?php echo base_url() . 'transaction/sms' ?>">Send SMS</a></li>
                    </div>
                    <li><a href="#">Global Topup</a></li>
                </ul>
            </li>
            <li><a href="<?php echo base_url(); ?>history/pending">Pending Request</a></li>
            <li><a href="javascript:void(0)" class="chld">History</a>
                <ul id="baby">
                                       				
                </ul>
            </li>

            <li><a href="<?php echo base_url() . 'reseller/get_reseller_list' ?>">Resellers</a></li>		
            <li><a href="<?php echo base_url(); ?>history/get_payment_history">Payment History</a></li>
            <li><a href="<?php echo base_url(); ?>history/get_receive_history">Receive History</a></li>	
            <li><a href="javascript:void(0)" class="chld">Report </a>
                <ul id="baby">
                    <li><a href="<?php echo base_url() . 'report/get_cost_and_profit' ?>">Cost &amp; Profit</a></li>
                    <li><a href="<?php echo base_url() . 'report/get_balance_report' ?>">Balance Report</a></li>
                    <li><a href="<?php echo base_url() . 'report/get_total_report' ?>">Total Report</a></li>
                    <li><a href="<?php echo base_url() . 'report/get_detailed_report' ?>">Detailed Report</a></li>
                    <li><a href="<?php echo base_url() . 'report/get_user_profit_loss' ?>">Profit/Loss Analysis</a></li>
                </ul>
            </li>
            
            <li><a href="#">Complain </a></li>-->
        <div class="clrGap">&nbsp;</div>
    </div>
</div>