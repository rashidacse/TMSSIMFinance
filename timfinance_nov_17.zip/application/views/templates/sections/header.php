<header class="main-header" style="width: 100%">
    <!-- Logo -->
    <a href="" class="logo-mini" style="float: left">
        <img class="img-responsive" alt="TIMFinance" src="<?php echo base_url();?>resources/images/logo.png"/>
    </a>
    <a href="" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><b>T</b>MIF</span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg"><b>TIM</b>Finance</span>
    </a>
    <nav class="navbar navbar-static-top">

        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </a>


        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">

            </ul>
        </div>
    </nav>
    <!-- Header Navbar: style can be found in header.less -->

</header>